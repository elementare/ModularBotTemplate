// import { Event } from "../../../types";


// export const event: Event<'afterReady'> = {
//     event: 'afterReady',
//     func: async (client, logger) => {
//         const profile1 = await client.profileHandler.findByKV({
//             "id": "840707271385284628",
//             "guildId": "1315508305321398344"
//         });
//         console.log(profile1[0])
//         console.log(profile1[0].data.economy)
//         const profile2 = await client.profileHandler.findByKV({
//             "id": "840707271385284628",
//             "guildId": "1259563750474907751"
//         });
//         console.log(profile2[0].data.economy)       

//     }
// }